package com.uparser.sequence;

import japa.parser.JavaParser;
import japa.parser.ast.CompilationUnit;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;


import com.uparser.generator.generator;
import com.uparser.main.selections;
import com.uparser.parsing.createClassCode;
import com.uparser.parsing.createClassCodeException;
import com.uparser.parsing.diagramGrammer;

public class CreateUmlSeqenceCode {

	 private static String projectName;
	 private static String filediagramGrammer;
	 public static StringBuilder source;
	 public static StringBuilder mainClassCode;
	 public static StringBuilder allObj;
	 public static List<String> classes;
	// public static List<String> classes;
	 public static StringBuilder allCode;
	 
	 public CreateUmlSeqenceCode() throws Exception {
	        projectName = endAfterLastPoint(selections.getPath(), "/");
	       
	        filediagramGrammer = selections.getOutputFile();
	        init(selections.getPath());
	    }
	 public void init(String path) throws Exception {
	      //  classes = new ArrayList<String>();
	    //    interfaces=new ArrayList<String>();
	      //  createListClasses(new File(path));
	     //   createListInterfaces(new File(path));
		 allObj=new StringBuilder();
		 classes = new ArrayList<String>();
		 createListClasses(new File(path));
	        source = new StringBuilder();
	        allCode=new StringBuilder();
	        mainClassCode=new StringBuilder();
	        //classes = new ArrayList<String>();
	        source.append("@startuml\n");
	        source.append("[-> Main \n");
	        source.append("activate Main \n");
	         	
	        
	        readFolder(new File(path));
	       // readFolder(new File(path));
	        System.out.println(path);
	        //neededTypeConnections();
	        System.out.println("String:"+allCode); 
	        //System.out.println("Objects:"+allObj); 
	        source.append("deactivate Main \n");
	        source.append("[<- Main \n");
	        source.append("@enduml\n");

	    }
	 private void readFolder(File path) throws Exception {
	        File[] folder = path.listFiles();
	        //------------------------------
	        for (int i = 0; i < folder.length; i++) {
	                if (folder[i].toString().toLowerCase().endsWith(".java")){
	            	
	            	 preCreateCU(folder[i]);
	            	 }
	            }
	  	//--------------------------------------------
	        
	       for (int i = 0; i < folder.length; i++) {
	        //System.out.println("readin folder... " + folder[i].toString());
	        if (folder[i].toString().toLowerCase().endsWith(".java")){
	        	
	        	 createCU(folder[i]);
	        	 //System.out.println("under create Cu()... ");
	          }
	        }
	      String contentStr=CreateUmlSeqenceCode.mainClassCode.toString();
	       genUMLSequenceCode.start(contentStr,"Main");  
	    	 //
	    	
	        //genUMLSequenceCode.start();  
	       // new genUMLSequenceCode(cu);
	 }
	 public void createCU(File path) throws Exception {
	        // creates an input stream for the file to be parsed
	    	
	        FileInputStream in = new FileInputStream(path);
	        CompilationUnit cu;
	        try {
	            // parse the file
	            cu = JavaParser.parse(in);
	            //System.out.println("printing cu:"+cu);
	        } finally {
	            in.close();
	        }
	        
	        	new genUMLSequenceCode(cu);
	           // new diagramGrammer(cu);
	        	
	       
	            //new genUMLSequenceCode(cu);
	       
	    }
	 public void preCreateCU(File path) throws Exception {
	        // creates an input stream for the file to be parsed
	    	
	        FileInputStream in = new FileInputStream(path);
	        CompilationUnit cu;
	        try {
	            // parse the file
	            cu = JavaParser.parse(in);
	            //System.out.println("printing cu:"+cu);
	        } finally {
	            in.close();
	        }
	        
	               	new umlSeqCodeClone(cu);
	       
	       
	    }
	 public static String endAfterLastPoint(String string, String separator){
	        String[] str = string.split(separator);
	        if(inArray(str, "src"))
	            return str[getIndexProjectName(str, "src")];
	        return str.length > 1 ? str[str.length-1] : string;
	    }
	 private static boolean inArray(String[] arr, String str){
	        for (int i = 0; i < arr.length; i++){
	            if(str.equals(arr[i]))
	                return true;
	            
	        }
	        return false;
	    }
	    
	    private static int getIndexProjectName(String[] arr, String str){
	        for (int i = 0; i < arr.length; i++){
	            if(str.equals(arr[i]))
	                return i - 1;

	        }
	        return 0;
	        
	    }
	    public static void writetoString() throws IOException, createClassCodeException {
	        String text = source.toString();
	        System.out.println("In write"+text);
	        if(text.trim().length() == 0)
	            throw new createClassCodeException("plantUML code is not generated");
	       
	        File file = new File(filediagramGrammer).getAbsoluteFile();

	        
	         if (!file.exists()) {
	            file.createNewFile();
	        }

	        //PrintWriter 
	        PrintWriter out = new PrintWriter(file.getAbsoluteFile());

	        try {
	            out.print(text);
	        } catch (Exception e){
	            throw new createClassCodeException("Error writing to file");
	        }finally {
	            out.close();
	        }
	        String srcPath=file.getAbsolutePath();
	        String descPath=selections.getPngPath();
	       
	       generator.generate(text, descPath, "png");
	    }


	    private void createListClasses(File path) throws createClassCodeException{
	        if(path.exists()) {
	            File[] folder = path.listFiles();

	            for (int i = 0; i < folder.length; i++) {
	                if (folder[i].isDirectory()) {
	                    createListClasses(folder[i]);
	                } else if (folder[i].toString().toLowerCase().endsWith(".java")) {
	               // 	System.out.println("Adding classes.."+getNameClass(folder[i].toString()));
	                    classes.add(getNameClass(folder[i].toString()));
	                //    System.out.println("Added class:"+classes);
	                }
	            }
	        }else 
	            throw new createClassCodeException("Folder is not exist");
	    }
	    private String getNameClass(String file){
	        String[] subString = file.split(Pattern.quote(System.getProperty("file.separator")));
	        String className = subString.length > 1 ? subString[subString.length - 1].replace(".java", "") : null;
	        return className;
	    }
}
