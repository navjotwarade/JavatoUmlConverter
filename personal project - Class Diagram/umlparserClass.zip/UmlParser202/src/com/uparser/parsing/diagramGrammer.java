package com.uparser.parsing;


import com.uparser.main.selections;

import japa.parser.ast.CompilationUnit;
import japa.parser.ast.ImportDeclaration;
import japa.parser.ast.PackageDeclaration;
import japa.parser.ast.body.*;
import japa.parser.ast.expr.NameExpr;
import japa.parser.ast.stmt.ThrowStmt;
import japa.parser.ast.type.ClassOrInterfaceType;
import japa.parser.ast.visitor.VoidVisitorAdapter;

import java.io.File;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;


public class diagramGrammer {
    private CompilationUnit cu;
   // public static List<String> getInstanceVar;
    public static StringBuilder privMembers;
    public static List<String> getInstanceVar;
    public static List<String> getMethodNames;
    public static List<String> privateMembers;
   // public static List<String> fieldTypes;
    public diagramGrammer(CompilationUnit cu) {
        this.cu = cu;
        getInstanceVar = new ArrayList<String>();
        getMethodNames = new ArrayList<String>();
        privMembers = new StringBuilder();
         getinterfaceStringB();
        scanClasses();
        System.out.println("All Field Types:"+createClassCode.getFieldTypes);
        System.out.println("variabl:"+getInstanceVar);
       System.out.println("Method names:"+getMethodNames);
    }
    private void scanClasses() {
        new VoidVisitorAdapter() {
            @Override
            public void visit(ClassOrInterfaceDeclaration n, Object arg) {
                if (n.isInterface())
                    createClassCode.srcStringB.append(Modifier.toString(Modifier.INTERFACE) + " ");
                else
                    createClassCode.srcStringB.append("class ");
                createClassCode.srcStringB.append(n.getName());
                if (n.getImplements() != null) {
                    for (ClassOrInterfaceType type : n.getImplements()) {
                        if (isavailable(type.getName())) {
                            createClassCode.connectStringB.append(fullClassName(type.getName()));
                            if (genericPackage(cu.getImports(), cu.getPackage()))
                                createClassCode.connectStringB.append(" <|. ");
                            else
                                createClassCode.connectStringB.append(" <|.. ");
                            createClassCode.connectStringB.append(fullClassName(n.getName()) + "\n");
                        } else if (true) {
                            createClassCode.srcStringB.append(" <<");
                            createClassCode.srcStringB.append(type.getName());
                            createClassCode.srcStringB.append(">> ");
                        }
                    }
                }
                if (n.getExtends() != null && !n.getName().toLowerCase().contains("exception")) {
                    for (ClassOrInterfaceType type : n.getExtends()) {
                        if (isavailable(type.getName())) {
                            createClassCode.connectStringB.append(fullClassName(type.getName()));
                            if (genericPackage(cu.getImports(), cu.getPackage()))
                                createClassCode.connectStringB.append(" <|- ");
                            else
                                createClassCode.connectStringB.append(" <|-- ");
                            break;
                        } else if (!n.getName().toLowerCase().contains("exception")) {
                            createClassCode.connectStringB.append(type.getName());
                            if (true) {
                                  } else
                                createClassCode.connectStringB.append(" <|- ");
                        }

                    }
                    createClassCode.connectStringB.append(fullClassName(n.getName()) + "\n");
                }
                if (n.getName().toLowerCase().contains("exception"))
                    createClassCode.srcStringB.append(" << (E,yellow) >> ");
                if (n.getMembers().toString().contains("public static void main(String[] args)") && !n.getName().equals("diagramGrammer"))
                    createClassCode.srcStringB.append(" << (C,yellow) start >> ");
                if (n.getMembers().size() > 0) {
                    createClassCode.srcStringB.append("{\n");
                    //---------------------------------------------------------------------------------------
                    getInstanceVariables(n);
                    getMethodsNames(n);
                   scanFields(n);
                    List<String> allThrows = new ArrayList<String>();
                    setConstructors(n, fullClassName(n.getName()), allThrows);
                    scanMethods(n, allThrows);
                    createClassCode.srcStringB.append("}\n");
                   accessClass(n);
                   setAggregation(n, fullClassName(n.getName()));
                    setdependStringB(n,fullClassName(n.getName()));
                    setdependStringBConstructor(n, fullClassName(n.getName()));
                } else
                    createClassCode.srcStringB.append("\n");
            }
        }.visit(cu, null);

    }

    private void getInstanceVariables(ClassOrInterfaceDeclaration n){
    	  new VoidVisitorAdapter() {
              @Override
              public void visit(FieldDeclaration cd, Object arg) {
            	  //System.out.println("Modifier:"+createClassCode.setModifier(cd.getModifiers()) +"variables:"+cd.getVariables());
                  String sd=cd.getVariables().toString();
                  String test1 = sd.replaceAll("[\\p{Ps}\\p{Pe}]", "");
            	  getInstanceVar.add(createClassCode.setModifier(cd.getModifiers())+""+test1);
                  }
          }.visit(n, null);
    }
    private void getMethodsNames(ClassOrInterfaceDeclaration n){
  	  new VoidVisitorAdapter() {
            @Override
            public void visit(MethodDeclaration m, Object arg) {
            	
            	 getMethodNames.add(createClassCode.setModifier(m.getModifiers())+""+m.getName());
          	    }
        }.visit(n, null);
  }
    private void setConstructors(ClassOrInterfaceDeclaration n, final String nameClass, final List allThrows) {
        new VoidVisitorAdapter() {
            @Override
            public void visit(ConstructorDeclaration n, Object arg) {
                if (n.getThrows() != null)
                    for (NameExpr expr : n.getThrows()) {
                        String throwName = (expr.getComment() != null
                                ?
                                expr.toString().replace(expr.getComment().toString(), "")
                                :
                                expr.toString());
                        
                        if (allThrows != null && isavailable(throwName) && noofConnections(allThrows, throwName) == 0) {

                            createClassCode.association.append(fullClassName(throwName));
                            createClassCode.association.append(" <.. ");
                            createClassCode.association.append(nameClass + "\n");
                            allThrows.add(throwName);
                        }
                    }

            }
        }.visit(n, null);

    }

   
    private boolean isavailable(String clazz) {
        for (String item : createClassCode.classes) {
            if (clazz.equals(item)) {
                return true;
            }
        }
        return false;

    }

    
    private void setAggregation(ClassOrInterfaceDeclaration n, final String nameClass) {
        StringBuilder writeClass = new StringBuilder();
        final List<String> typeFields = new ArrayList<String>();
        new VoidVisitorAdapter() {
            @Override
            public void visit(FieldDeclaration n, Object arg) {
                if (n != null && !Modifier.toString(n.getModifiers()).contains("static"))
                    typeFields.add(n.getType().toString());
            }
        }.visit(n, null);
        //----------------------------------------
     //  System.out.println("Fieldtypes SB: "+createClassCode.getFieldTypes);
        //----------------------------------------

        System.out.println("typefields:"+typeFields+"classes"+createClassCode.classes);
        for (String item : typeFields) {

            for (String cl : createClassCode.classes) {
                if ((item.equals(cl) || containsClass(item, cl))
                        && !fullClassName(cl).equals(nameClass)
                        && !writeClass.toString().contains("." + cl + ".")
                        && !createClassCode.getAggClass.toString().contains(nameClass+"-"+cl)
                        && !createClassCode.getAggClass.toString().contains(cl+"-"+nameClass)){
                	System.out.println("c1:"+cl+"item:"+item+"\n");
                	
                	//for(String cl1: createClassCode.classes){
                	 String s2=createClassCode.getFieldTypes.toString();
             		String requiredString = s2.substring(s2.indexOf(cl+"{") + 2, s2.indexOf("}"+cl));	
                     System.out.println(cl+":req String :"+requiredString); 
                     
                     createClassCode.aggregation.append(nameClass);
                     System.out.println("nameClass:"+ nameClass);
                    if(requiredString.contains(nameClass)){
                    	if(requiredString.contains("Collection<"+nameClass+">")){
                    		//createClassCode.aggregation.append(nameClass);
                    		createClassCode.aggregation.append(" \"0..*\" ");
                    		//break;
                    	}else if(requiredString.contains(nameClass)) {
                    		//createClassCode.aggregation.append(nameClass);
                    		createClassCode.aggregation.append(" \"0..1\" ");
                    		
                    	}
                    	
                    }
                     
                	//}// end of for stmnt
                	//createClassCode.aggregation.append(" \"0..1\" ");
                    createClassCode.aggregation.append(" -- ");
                	                   	
                	if(item.contains("Collection")){
                		createClassCode.aggregation.append(" \"0..*\" ");
                	}else{
                		createClassCode.aggregation.append(" \"0..1\" ");
                	}
                	 String connect = fullClassName(cl);
                     createClassCode.aggregation.append(connect + "\n");
                     createClassCode.getAggClass.append(nameClass+"-"+connect);
                	
                	
                }
               
                            	
                	
              //  }  // end of if
            }
        }
    }
    private void setdependStringB(ClassOrInterfaceDeclaration n, final String nameClass) {
    	 final List<String> typeParam = new ArrayList<String>();
        new VoidVisitorAdapter() {
            @Override
            public void visit(MethodDeclaration n, Object arg) {
            	if(n!=null&&n.getParameters()!=null){
            	System.out.println("parameters:    "+n.getParameters());
            	String cl=n.getParameters().toString();
            	String test = cl.replaceAll("[\\p{Ps}\\p{Pe}]", "");
            	String[]clas=test.split(" ");
            	System.out.println("parameters class:"+clas[0]);
            	System.out.println("After parameters class interfaceStringB:"+createClassCode.interfaceStringB.toString());
            	String intfer=createClassCode.interfaceStringB.toString();
                              if(n!=null&& (createClassCode.classes).contains(clas[0])&&intfer.contains(clas[0]))  {
                            	//  System.out.println("Success:");
                            //	  String v=n.().toString();
                            	//  System.out.println("Success:"+v);
                            	 createClassCode.dependStringB.append(clas[0]);
                                  createClassCode.dependStringB.append("<..");
                                  createClassCode.dependStringB.append(nameClass);
                                  createClassCode.dependStringB.append(":<uses>"+"\n");
                              }
                     }  
                    }

            
        }.visit(n, null);
    }
    private void setdependStringBConstructor(ClassOrInterfaceDeclaration n, final String nameClass) {
   	 final List<String> typeParam = new ArrayList<String>();
       new VoidVisitorAdapter() {
           @Override
           public void visit(ConstructorDeclaration n, Object arg) {
           	if(n!=null&&n.getParameters()!=null){
           	System.out.println("parameters:    "+n.getParameters());
           	String cl=n.getParameters().toString();
           	String test = cl.replaceAll("[\\p{Ps}\\p{Pe}]", "");
           	String[]clas=test.split(" ");
           	System.out.println("parameters class:"+clas[0]);
           	String intfer=createClassCode.interfaceStringB.toString();
            if(n!=null&& (createClassCode.classes).contains(clas[0])&&intfer.contains(clas[0]))  {
                           
                           	 createClassCode.dependStringB.append(clas[0]);
                                 createClassCode.dependStringB.append(" <.. ");
                                 createClassCode.dependStringB.append(nameClass);
                                 createClassCode.dependStringB.append("\n");
                             }
                    }  
                   }

           
       }.visit(n, null);
   }

    
    private int noofConnections(List<String> classes, String checkClass) {
        int quantity = 0;
        for (String clazz : classes) {
            if (clazz.equals(checkClass))
                quantity++;
        }
        return quantity;
    }

    
   

    
    private void accessClass(ClassOrInterfaceDeclaration n) {
        new VoidVisitorAdapter() {
            @Override
            public void visit(ClassOrInterfaceDeclaration n, Object arg) {

                for (BodyDeclaration body : n.getMembers()) {

                    if (body.toString().contains(" class ") && isClass(body)) {

                        ClassOrInterfaceDeclaration cu = (ClassOrInterfaceDeclaration) body;
                        scanInsideClasses(cu, n.getName());
                    }
                }
            }
        }.visit(n, null);

    }

    private boolean isClass(BodyDeclaration body) {
        String lines = body.getComment() != null ? body.toString().replace(body.getComment().toString(), "") : body.toString();
        String[] strings = lines.split(System.getProperty("line.separator"));
        String string = strings[0];
        if ((string.startsWith("protected ")
                || string.startsWith("private ")
                || string.startsWith("class ")
                || string.startsWith("abstract")
                || string.startsWith("static"))
                && string.contains(" class "))
            return true;
        return false;

    }

    private void scanInsideClasses(ClassOrInterfaceDeclaration n, final String parentClass) {
        new VoidVisitorAdapter() {
            @Override
            public void visit(ClassOrInterfaceDeclaration n, Object arg) {

                if (n.isInterface())
                    createClassCode.srcStringB.append(Modifier.toString(Modifier.INTERFACE) + " ");
                else
                    createClassCode.srcStringB.append("class ");
                createClassCode.srcStringB.append(n.getName() + "_" + parentClass);

                if (n.getImplements() != null) {
                    for (ClassOrInterfaceType type : n.getImplements()) {
                        if (isavailable(type.getName())) {
                            createClassCode.connectStringB.append(fullClassName(type.getName()));
                            if (genericPackage(cu.getImports(), cu.getPackage()))
                                createClassCode.connectStringB.append(" <|. ");
                            else
                                createClassCode.connectStringB.append(" <|.. ");

                            createClassCode.connectStringB.append(fullClassName(n.getName()) + "_");
                            createClassCode.connectStringB.append(parentClass + "\n");
                        } else if (true) {
                            createClassCode.srcStringB.append(" <<");
                            createClassCode.srcStringB.append(type.getName());
                            if (n.getImplements().size() > 1)
                                createClassCode.srcStringB.append(",");
                            createClassCode.srcStringB.append(">> ");
                        }
                    }
                }
                if (n.getExtends() != null && !n.getName().toLowerCase().contains("exception")) {
                    for (ClassOrInterfaceType type : n.getExtends()) {
                        if (isavailable(type.getName())) {
                            createClassCode.connectStringB.append(fullClassName(type.getName()));
                            if (genericPackage(cu.getImports(), cu.getPackage()))
                                createClassCode.connectStringB.append(" <|- ");
                            else
                                createClassCode.connectStringB.append(" <|-- ");
                            break;
                        } else if (!n.getName().toLowerCase().contains("exception")) {
                            createClassCode.connectStringB.append(type.getName());
                            if (true) {
                                
                            } else
                                createClassCode.connectStringB.append(" <|- ");
                        }

                    }


                    createClassCode.connectStringB.append(fullClassName(n.getName()) + "_");
                    createClassCode.connectStringB.append(parentClass + "\n");
                }

                if (n.getName().toLowerCase().contains("exception"))
                    createClassCode.srcStringB.append(" << (E,yellow) >> ");

                if (n.getMembers().size() > 0) {
                    createClassCode.srcStringB.append("{\n");

                    scanFields(n);

                    scanMethods(n, null);

                    createClassCode.srcStringB.append("}\n");

                  //  setComposition(getPackage() + n.getName() + "_" + parentClass, parentClass);
                } else
                    createClassCode.srcStringB.append("\n");
            }
        }.visit(n, null);
    }

  
      
    private void scanFields(ClassOrInterfaceDeclaration clazz) {

        new VoidVisitorAdapter() {
            @Override
            public void visit(FieldDeclaration n, Object arg) {
            	
            	
            	//--------------------------------------------------------------
            	String modi=createClassCode.setModifier(n.getModifiers());
            	//System.out.println("Modifiesr:"+modi);
               
            //for(String clazz:createClassCode.classes){
            	//System.out.println("n.getType:"+n.getType()+"clazz:"+clazz+"\n");
            	String sv=n.getType().toString();
            	if(createClassCode.classes.toString().contains(sv)
            			|| sv.contains("Collection")){
            		
            	}
            	else{
            	if((modi.contains("-")||modi.contains("+"))){
            	
            		
              //  createClassCode.srcStringB.append(createClassCode.setModifier(n.getModifiers()));
           //     System.out.println("getVariables:"+n.getVariables().toString());
                for (VariableDeclarator var : n.getVariables()) {
                	
                	//-----------------------------------------
                	String s=var.getId().toString();
                	if((org.apache.commons.lang.StringUtils.containsIgnoreCase(getMethodNames.toString(), "get"+var.getId().toString()) ||  org.apache.commons.lang.StringUtils.containsIgnoreCase(getMethodNames.toString(), "set"+var.getId().toString()))&& modi.contains("-")){
                	     privMembers.append(s);
                		 createClassCode.srcStringB.append(" +");
                	}else{
                		createClassCode.srcStringB.append(createClassCode.setModifier(n.getModifiers()));
                	}
                	//------------------------------------------
                	createClassCode.srcStringB.append("" + var.getId());
                	createClassCode.srcStringB.append(":");
                    createClassCode.srcStringB.append(n.getType()+"\n");
                    //--------------------------------------
                   }
                            
            	//--------------------------------------------------------------
                }
              }//end of if stmnt
            //}
           }
        }.visit(clazz, null);
    }

        public void scanMethods(final ClassOrInterfaceDeclaration clazz, final List allThrows) {

        new VoidVisitorAdapter() {
            @Override
            public void visit(MethodDeclaration n, Object arg) {
            	String meth=createClassCode.setModifier(n.getModifiers());
                //checkGetSet()
            	
            	System.out.println("method modieefer:"+meth+"Methodnames:"+n.getName()+" privmembers"+privMembers.toString());
            	String s1=n.getName().toString();
            	if(meth.contains("+")){
            	//----------------------------------------------------------------------	
            	
            	if((s1.startsWith("get")||s1.startsWith("set"))&& org.apache.commons.lang.StringUtils.containsIgnoreCase(s1,privMembers.toString() )){
            		
            	}else
            	{
                createClassCode.srcStringB.append(createClassCode.setModifier(n.getModifiers()));
               
                createClassCode.srcStringB.append(n.getName() + "(");
                if (n.getParameters() != null) {
                    setParams(n.getParameters());
                }
                createClassCode.srcStringB.append(")");
                createClassCode.srcStringB.append(":");
                if (n.getType() != null)
                    createClassCode.srcStringB.append(n.getType() + " \n");

                if (n.getThrows() != null) {

                    for (NameExpr expr : n.getThrows()) {
                        String throwName = (expr.getComment() != null
                                ?
                                expr.toString().replace(expr.getComment().toString(), "")
                                :
                                expr.toString());
                        if (allThrows != null && isavailable(throwName) && noofConnections(allThrows, throwName) == 0) {

                            createClassCode.association.append(fullClassName(throwName));
                            createClassCode.association.append(" <.. ");
                            createClassCode.association.append(fullClassName(clazz.getName()) + "\n");
                            allThrows.add(throwName);
                        }
                    }

                }
            	}
                //--------
                }  //
            }
        }.visit(clazz, null);

    }

    
    private void setParams(List<Parameter> parameters) {

        for (Parameter parameter : parameters) {
        	createClassCode.srcStringB.append(parameter.getId()+":");
            createClassCode.srcStringB.append(parameter.getType());
            
            if (parameters.size() > 1 && parameters.indexOf(parameter) < parameters.size() - 1)
                createClassCode.srcStringB.append(", ");
        }
    }

    private String fullClassName(String nameClass) {
        if (cu.getImports() != null && cu.getImports().size() > 0)
            for (ImportDeclaration imp : cu.getImports()) {

                if (imp.getName().toString().toLowerCase().endsWith("." + nameClass.toLowerCase()))
                    return imp.getName().toString();

                StringBuilder builder = new StringBuilder();
                builder.append(selections.getPath());
                builder.append(System.getProperty("file.separator"));
                builder.append("src");
                builder.append(System.getProperty("file.separator"));
                builder.append(imp.getName().toString().replace(".", System.getProperty("file.separator")));
                builder.append(System.getProperty("file.separator"));
                builder.append(nameClass);
                builder.append(".java");
                File file = new File(builder.toString());

                if (file.exists())
                    return imp.getName().toString() + "." + nameClass;


            }
        return getPackage() + nameClass;
    }

    private boolean genericPackage(List<ImportDeclaration> imports, PackageDeclaration pack) {
        if (imports != null && imports.size() > 0 && pack != null)
            for (ImportDeclaration imp : imports) {
                if (imp.getName().toString().contains(pack.getName().toString()))
                    return true;
            }
        return false;
    }

    private boolean containsClass(String where, String what) {
        if (where.contains("<" + what + ">") || where.contains(what + "["))
            return true;
        return false;

    }

   

    private String getPackage() {

        return (cu.getPackage() == null ? "" : cu.getPackage().getName().toString() + ".");

    }
    private void getinterfaceStringB() {
    	  new VoidVisitorAdapter() {
              @Override
              public void visit(ClassOrInterfaceDeclaration n, Object arg) {
            	  if (n.isInterface()){
            		  System.out.println("interface name:"+n.getName());
                      createClassCode.interfaceStringB.append(n.getName()+" ");
            	  }
              }
        
    }.visit(cu,null);
    }
    public void getfieldTypes() {
    	new VoidVisitorAdapter() {
    		@Override
            public void visit(ClassOrInterfaceDeclaration c, Object arg) {
    	//---------------------------------------------------------------
    	createClassCode.getFieldTypes.append(c.getName()+"{");
    	 new VoidVisitorAdapter() {
             @Override
             public void visit(FieldDeclaration f, Object arg) {
                 if (c != null && !Modifier.toString(f.getModifiers()).contains("static"))
                 { 
                	// createClassCode.getFieldTypes.append(v.getName()+"{");	 
                   createClassCode.getFieldTypes.append(f.getType().toString()+" ,");
                 //  createClassCode.getFieldTypes.append("}");
                 }
             }
         }.visit(c, null);
         createClassCode.getFieldTypes.append("}   "); 
        //---------------------------------------------------------------
    	}
     }.visit(cu,null);
  
    }
}
