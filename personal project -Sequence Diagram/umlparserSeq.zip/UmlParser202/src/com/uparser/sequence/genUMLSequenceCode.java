package com.uparser.sequence;

import java.lang.reflect.Method;



import com.uparser.main.selections;
import com.uparser.parsing.createClassCode;

import japa.parser.ast.CompilationUnit;
import japa.parser.ast.ImportDeclaration;
import japa.parser.ast.PackageDeclaration;
import japa.parser.ast.body.*;
import japa.parser.ast.expr.NameExpr;
import japa.parser.ast.stmt.ThrowStmt;
import japa.parser.ast.type.ClassOrInterfaceType;
import japa.parser.ast.visitor.VoidVisitorAdapter;

import java.io.File;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class genUMLSequenceCode {
    private CompilationUnit cu;
    public static String s9;
   // private static String ="";
    boolean hasMethod = false;
	
    public genUMLSequenceCode(CompilationUnit cu){
    	 this.cu = cu;
    	 //-----------------------------------------------
    	
    	 
    	 //-----------------------------------------------
    	 getMainFunc(); 
    	// System.out.println("main class");
    	 
    }
 public static void	start(String methodString,String srcMethod){
	 Scanner scanner = new Scanner(methodString);
	 while (scanner.hasNextLine()) {   //
  	   String line = scanner.nextLine();
  	   if(line.contains("(")){
  		   if(line.contains(")")){
  		// process the line
              //  if()    			   
  			   int num=line.indexOf("{new}");
  			//   String sub=line.substring(num, line.indexOf("("));
  			 //  System.out.println("sub:"+num);
  			   
  			 //  String str = "ZZZZL <%= dsn %> AFFF <%= AFG %>";
  			  Pattern pattern1 = Pattern.compile("new(.*?)\\(");
  			  Matcher matcher = pattern1.matcher(line);
  			    while (matcher.find()) {
  			    	String reqString="";
  			    	String destConstr=matcher.group(1).toString().replaceAll(" ", "");
  			    	CreateUmlSeqenceCode.source.append(srcMethod+"->"+destConstr+" : Constructor "+destConstr+"\n");
  			    	CreateUmlSeqenceCode.source.append("activate "+destConstr+"\n");
  			    	//start
  			    	String s2=CreateUmlSeqenceCode.allCode.toString();
  			    	if(s2.indexOf("Constr"+destConstr+"{")!=-1 && s2.indexOf("}"+"Constr"+destConstr)!=-1){
  			    	 reqString = s2.substring(s2.indexOf("Constr"+destConstr+"{")+8, s2.indexOf("}"+"Constr"+destConstr));
  			    	}
  			    	//System.out.println(s2.indexOf("Constr"+destConstr+"{")+reqString);
  			    //	if(s2.contains())
  			    	start(reqString,destConstr);
  			      //System.out.println("this is construct call:"+matcher.group(1));
  			    	
  			      CreateUmlSeqenceCode.source.append(destConstr+"-->"+srcMethod+"\n");
  			      CreateUmlSeqenceCode.source.append("deactivate "+destConstr+"\n");
  			    }
  			    //----------------------------------------------
  			    Pattern pattern2 = Pattern.compile(" "+"(.*?)\\.(.*?)\\(");
  			    Matcher matcher2 = pattern2.matcher(line);
  			    while (matcher2.find()) {
  			    	String destMethod=matcher2.group(2).toString().replaceAll(" ", "");
  			    	String funCall=destMethod;
  			    	//------------------------------------------------------------
  			    	String callFunc=matcher2.group(2).toString().replaceAll(" ", "");
  			    	String CallingClass=checkMethodinClass1(callFunc);
  			    	System.out.println("Callling Class:"+CallingClass);
  			    	if(CallingClass!=null){
  			    		System.out.println("after Callling Class:"+CallingClass+srcMethod);
  			    		destMethod=CallingClass;
  			    	}
  			    //--------------------------------------------------
  			    	String CalledClass=checkMethodinClass1(srcMethod);
  			    	//s9=srcMethod;
  			    	System.out.println("Called Class:"+CalledClass);
  			    	if(CalledClass!=null){
  			    		System.out.println("after Callled Class:"+CalledClass);
  			    	//	destMethod=CallingClass;
  			    		 s9=srcMethod;
  			    	     s9=CalledClass;
  			    	     
  			    	}else  {
  			    		s9=srcMethod;
  			    	}
  			    	if(CalledClass.equals("")){
  			    		s9=srcMethod;
  			    	}
  			    	//--------------------------------------------------
  			    	//System.out.println("s9: "+s9+"|");
  			    	//---------------------------------------------------
  			    	CreateUmlSeqenceCode.source.append(s9+"->"+destMethod+" : "+funCall+"\n");
  			    	CreateUmlSeqenceCode.source.append("activate "+destMethod+"\n");
  			    	//----------------------------------------------------------
  			    	
  			    	//--------------------------------
  			    	String reqString="";
  			    	String s2=CreateUmlSeqenceCode.allCode.toString();
  			    	if(s2.indexOf("method"+funCall+"{")!=-1 && s2.indexOf("}"+"method"+funCall)!=-1){
  			    	 reqString = s2.substring(s2.indexOf("method"+funCall+"{")+8, s2.indexOf("}"+"method"+funCall));
  			    	}
  			    	//System.out.println(s2.indexOf("method"+destMethod+"{")+reqString);
  			    //	if(s2.contains())
  			    	start(reqString,funCall);
  			    	//--------------------------------
  			     // System.out.println("this is method call:"+matcher2.group(2));
  			    //	checkMethodinClass1()
  			    	System.out.println("s9: "+s9+"|");
  			    	if(srcMethod.contains("Main")){
	  			    		CreateUmlSeqenceCode.source.append(destMethod+"-->"+"Main"+"\n");
	  			    	}else{
  			    	 if(CallingClass.equals(CalledClass)){
  			    		if(srcMethod.contains("Main")){
  	  			    		CreateUmlSeqenceCode.source.append(destMethod+"-->"+"Main"+"\n");
  	  			    	}else{
  			    		CreateUmlSeqenceCode.source.append(destMethod+"-->"+CallingClass+"\n");
  	  			    	}
  	  			    	
  			    	}	
  			    	
  			    	else{
  			      CreateUmlSeqenceCode.source.append(destMethod+"-->"+srcMethod+"\n");
  			    	}
	  			    	}	 
  			      CreateUmlSeqenceCode.source.append("deactivate "+destMethod+"\n");
  			      
  			    }
  			   
  		   }
  	   }
  	  }
	 scanner.close();
 }//end of start func
 private static String checkMethodinClass(String methodName){
	  String a="";
	 String s4="";
	 for(String claz:CreateUmlSeqenceCode.classes){
		 String s3=CreateUmlSeqenceCode.allObj.toString();
		 if(s3.indexOf("class"+claz+"{")!=-1 && s3.indexOf("}"+"class"+claz)!=-1){
		   s4=s3.substring(s3.indexOf("class"+claz+"{")+7, s3.indexOf("}"+"class"+claz));
		 }
		// System.out.println("s4:"+s4);
		 if(s4.contains(methodName)){
			 System.out.println("returned class:"+claz+"methodname"+methodName);
			 return claz;
		 }
	 }
	 System.out.println("a:"+a);
	    return null;
 }
 private static String checkMethodinClass1(String methodName){
	  String a="";
	 String s4="";
	 for(String claz:CreateUmlSeqenceCode.classes){
		 String s3=CreateUmlSeqenceCode.allCode.toString();
		 if(s3.indexOf("class"+claz+"{")!=-1 && s3.indexOf("}"+"class"+claz)!=-1){
			   s4=s3.substring(s3.indexOf("class"+claz+"{")+7, s3.indexOf("}"+"class"+claz));
			 //  System.out.println("s4--:"+s4);
			   if(claz.equals("A")){   //do not check if the class is A
				   continue;
			   }
			   if(s4.contains(methodName)){
				   System.out.println("returned class: "+claz+" methodname "+methodName);
				   return claz;
			   }
			 }
	 }
	
	    return a;
}
 
 private  void getMainFunc() {
    	
    	 new VoidVisitorAdapter() {
                @Override
                public void visit(ClassOrInterfaceDeclaration n, Object arg) {
                      
                	  if(n!=null){
                		  getMainClass(n);
                	
                	}
                	
                	
		};
    	
    	
    }.visit(cu, null);
    
 
  }
 private void getMainClass(ClassOrInterfaceDeclaration n){
	 new VoidVisitorAdapter() {
         @Override
         public void visit(MethodDeclaration m, Object arg) {
                       	/*if(m!=null&&m.getName().toString().contains("main")){
                       		String s=m.getBody().toString();
                       		if(s.contains("()")
                       	}*/
                       System.out.println("in getMainClass "+m.getName()+"\n");        	 
        	        getMethinMeth(m);
         	// getMethodNames.add(createClassCode.setModifier(m.getModifiers())+""+m.getName());
       	    }
     }.visit(n, null);
	 
    }
 private void getMethinMeth(MethodDeclaration k){
	 new VoidVisitorAdapter() {
         @Override
         public void visit(MethodDeclaration l, Object arg) {
                       	/*if(m!=null&&m.getName().toString().contains("main")){
                       		String s=m.getBody().toString();
                       		if(s.contains("()")
                       	}*/
        	
        	// System.out.println("in getmethmeth:"+l.getName()+" \n");        
        	      //  getMethinMeth(m);
         	// getMethodNames.add(createClassCode.setModifier(m.getModifiers())+""+m.getName());
       	    }
     }.visit(k, null);
	 
    }
    
    
}