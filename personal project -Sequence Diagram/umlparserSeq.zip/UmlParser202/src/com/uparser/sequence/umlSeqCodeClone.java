package com.uparser.sequence;

//import ch.qos.logback.classic.boolex.GEventEvaluator;

import com.uparser.main.selections;
import com.uparser.parsing.createClassCode;

import japa.parser.ast.CompilationUnit;
import japa.parser.ast.ImportDeclaration;
import japa.parser.ast.PackageDeclaration;
import japa.parser.ast.body.*;
import japa.parser.ast.expr.NameExpr;
import japa.parser.ast.stmt.ThrowStmt;
import japa.parser.ast.type.ClassOrInterfaceType;
import japa.parser.ast.visitor.VoidVisitorAdapter;

import java.io.File;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class umlSeqCodeClone {
	 public CompilationUnit cu;
	public umlSeqCodeClone(CompilationUnit cu) {
		// TODO Auto-generated constructor stub
		this.cu = cu;
		parseAll();
	}
	public void parseAll() {
    	new VoidVisitorAdapter() {
    		@Override
            public void visit(ClassOrInterfaceDeclaration c, Object arg) {
    	//---------------------------------------------------------------
    	//createClassCode.getFieldTypes.append(c.getName()+"{");
    		CreateUmlSeqenceCode.allCode.append("class"+c.getName()+"{");
    		getContructorDec(c);
    	 getMethodsDec(c);
    	 CreateUmlSeqenceCode.allCode.append("}class"+c.getName()+"  \n");
        // createClassCode.getFieldTypes.append("}"+c.getName()+"  "); 
        //---------------------------------------------------------------
    	}
     }.visit(cu,null);
  
    }
	public void getMethodsDec(ClassOrInterfaceDeclaration n){
		new VoidVisitorAdapter() {
            @Override
            public void visit(MethodDeclaration f, Object arg) {
                if (n != null)
                { 
               	CreateUmlSeqenceCode.allCode.append("method"+f.getName()+"");
               	 // getMethodsDec(f);
               	//if(f.getBody())
               	CreateUmlSeqenceCode.allCode.append(f.getBody().toString());
               	if(f.getName().toString().contains("main")){
               	CreateUmlSeqenceCode.mainClassCode.append(f.getBody().toString());
               	System.out.println(f.getBody().toString());
               	}
               	//--------------------------------------------------------------------
               	CreateUmlSeqenceCode.allObj.append("class"+n.getName()+"{"+"\n");
               	for(String claz:CreateUmlSeqenceCode.classes){
               	 Scanner scanner = new Scanner(f.getBody().toString());
            	 while (scanner.hasNextLine()) {   //
              	   String line = scanner.nextLine();
              	  Pattern pattern1 = Pattern.compile(claz+" "+"(.*?)"+"= "+"new "+claz+"\\(");
      			  Matcher matcher = pattern1.matcher(line);
      			    while (matcher.find()) {
      			    	System.out.println("this call:"+matcher.group(1)+",");
      			    	CreateUmlSeqenceCode.allObj.append(matcher.group(1)+"\n");
      			    }
               	}
            		 
               	}
               	CreateUmlSeqenceCode.allObj.append("new"+" "+n.getName()+"()"+"\n");
               	CreateUmlSeqenceCode.allObj.append("}"+"class"+n.getName()+"\n");
               	//---------------------------------------------------------------------
               //   createClassCode.getFieldTypes.append(f.getType().toString()+" ");
                CreateUmlSeqenceCode.allCode.append("method"+f.getName()+" \n");
                }
            }
        }.visit(n, null);
	}
	public void getContructorDec(ClassOrInterfaceDeclaration n){
		new VoidVisitorAdapter() {
            @Override
            public void visit(ConstructorDeclaration f, Object arg) {
                if (n != null)
                { 
               	CreateUmlSeqenceCode.allCode.append("Constr"+f.getName()+"");
               	 // getMethodsDec(f);
               	//if(f.getBody())
               	CreateUmlSeqenceCode.allCode.append(f.getBlock().toString());
               
               //   createClassCode.getFieldTypes.append(f.getType().toString()+" ");
                CreateUmlSeqenceCode.allCode.append("Constr"+f.getName()+" \n");
                }
            }
        }.visit(n, null);
	}
}
