package com.uparser.parsing;


public class createClassCodeException extends Exception {
    public createClassCodeException(String message) {
        super(message);
    }
}
