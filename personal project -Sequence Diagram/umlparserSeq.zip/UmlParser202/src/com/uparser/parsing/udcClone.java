package com.uparser.parsing;


import com.uparser.main.selections;

import japa.parser.ast.CompilationUnit;
import japa.parser.ast.ImportDeclaration;
import japa.parser.ast.PackageDeclaration;
import japa.parser.ast.body.*;
import japa.parser.ast.expr.NameExpr;
import japa.parser.ast.stmt.ThrowStmt;
import japa.parser.ast.type.ClassOrInterfaceType;
import japa.parser.ast.visitor.VoidVisitorAdapter;

import java.io.File;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;


public class udcClone {
	 public CompilationUnit cu;
	public udcClone(CompilationUnit cu) {
		// TODO Auto-generated constructor stub
		this.cu = cu;
		getfieldTypes();
	}
	public void getfieldTypes() {
    	new VoidVisitorAdapter() {
    		@Override
            public void visit(ClassOrInterfaceDeclaration c, Object arg) {
    	//---------------------------------------------------------------
    	createClassCode.getFieldTypes.append(c.getName()+"{");
    	 nestGetFieldTypes(c);
    	 
         createClassCode.getFieldTypes.append("}"+c.getName()+"  "); 
        //---------------------------------------------------------------
    	}
     }.visit(cu,null);
  
    }
	public void nestGetFieldTypes(ClassOrInterfaceDeclaration n){
		new VoidVisitorAdapter() {
            @Override
            public void visit(FieldDeclaration f, Object arg) {
                if (n != null && !Modifier.toString(f.getModifiers()).contains("static"))
                { 
               	// createClassCode.getFieldTypes.append(v.getName()+"{");	 
                  createClassCode.getFieldTypes.append(f.getType().toString()+" ");
                //  createClassCode.getFieldTypes.append("}");
                }
            }
        }.visit(n, null);
	}
}
