package com.uparser.parsing;

import japa.parser.JavaParser;
import japa.parser.ast.CompilationUnit;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import com.uparser.generator.generator;
import com.uparser.main.selections;

public class createClassCode{
	public static StringBuilder aggregation;
    public static StringBuilder composition;
    public static StringBuilder association;
    
	public static StringBuilder srcStringB;
    public static StringBuilder connectStringB;
    public static StringBuilder dependStringB;//edit by me
    public static StringBuilder interfaceStringB;
    public static StringBuilder getInstanceVariables;
    public static StringBuilder getAggClass;
    public static StringBuilder getFieldTypes;
    private static String filecreateClassCode;
    
   // public static final String UML_TEMPLATE = "uml_templates";
    public static List<String> classes;
   // public static List<String> getInstanceVar;
 //   public static List<String> getMethodNames;
  //  public static List<String> interfaceStringB;
    private static String projectName;
    private int typeconnectStringB;
	public createClassCode() throws Exception {
        projectName = endAfterLastPoint(selections.getPath(), "/");
       
        filecreateClassCode = selections.getOutputFile();
        init(selections.getPath());
     }

    public void init(String path) throws Exception {
        classes = new ArrayList<String>();
    //    interfaceStringB=new ArrayList<String>();
        listClasses(new File(path));
        //getInstanceVar = new ArrayList<String>();
      //  getMethodNames = new ArrayList<String>();
     //   createListinterfaceStringB(new File(path));
        srcStringB = new StringBuilder();
        connectStringB = new StringBuilder();
        aggregation = new StringBuilder();
        composition = new StringBuilder();
        association = new StringBuilder();
        getAggClass=new StringBuilder();
        dependStringB=new StringBuilder();
        interfaceStringB=new StringBuilder();
        getInstanceVariables=new StringBuilder();
        getFieldTypes=new StringBuilder();
        srcStringB.append("@startuml\n");
        srcStringB.append("skinparam classAttributeIconSize 0"+"\n");

        
        readFolder(new File(path));
        System.out.println(path);
        addAllconnectStringB();
        srcStringB.append("@enduml\n");

    }

    private void readFolder(File path) throws Exception {
        File[] folder = path.listFiles();
        //------------------------------
        for (int i = 0; i < folder.length; i++) {
            //System.out.println("readin folder... " + folder[i].toString());
            if (folder[i].toString().toLowerCase().endsWith(".java")){
            	
            	 preCreateCU(folder[i]);
            	 //System.out.println("under create Cu()... ");
              }
            }
        System.out.println("in CreateUmlCode, field types:"+getFieldTypes);
//--------------------------------------------
       for (int i = 0; i < folder.length; i++) {
        //System.out.println("readin folder... " + folder[i].toString());
        if (folder[i].toString().toLowerCase().endsWith(".java")){
        	
        	 createCU(folder[i]);
        	 //System.out.println("under create Cu()... ");
          }
        }
        
     
    }
    public void preCreateCU(File path) throws Exception {
        // creates an input stream for the file to be parsed
    	
        FileInputStream in = new FileInputStream(path);
        CompilationUnit cu;
        try {
            // parse the file
            cu = JavaParser.parse(in);
           // System.out.println("printing cu:"+cu);
        } finally {
            in.close();
        }
        
      
        	//createClassCode udc=new createClassCode(cu);
        	udcClone ud=new udcClone(cu); 
            //new createClassCode(cu);
      
    }
   
    public void createCU(File path) throws Exception {
        // creates an input stream for the file to be parsed
    	
        FileInputStream in = new FileInputStream(path);
        CompilationUnit cu;
        try {
            // parse the file
            cu = JavaParser.parse(in);
           // System.out.println("printing cu:"+cu);
        } finally {
            in.close();
        }
        
            new diagramGrammer(cu);
      
    }

    public static String setModifier(int mod) {
        switch (mod) {
            case Modifier.PUBLIC:
                return " +";
            case Modifier.PRIVATE:
                return (" -");
            case Modifier.PROTECTED:
                return (" #");
            case Modifier.STATIC:
                return (" {static}");
            case Modifier.PUBLIC | Modifier.STATIC:
                return (" +{static}");
            case Modifier.PUBLIC | Modifier.STATIC | Modifier.FINAL:
                return (" +{static}");
            case Modifier.PROTECTED | Modifier.STATIC:
                return (" #{static}");
            case Modifier.PROTECTED | Modifier.STATIC | Modifier.FINAL:
                return (" #{static}");
            case Modifier.PRIVATE | Modifier.STATIC:
                return (" -{static}");
            case Modifier.PRIVATE | Modifier.STATIC | Modifier.FINAL:
                return (" -{static}");
            case Modifier.PUBLIC | Modifier.FINAL:
                return (" +");
            case Modifier.PROTECTED | Modifier.FINAL:
                return (" #");
            case Modifier.PRIVATE | Modifier.FINAL:
                return (" -");
            case Modifier.ABSTRACT:
                return (" {abstract}");
            default:
                return "";
        }
    }

       public static void writetoString() throws IOException, createClassCodeException {
        String text = srcStringB.toString();
        System.out.println("In write"+text);
        if(text.trim().length() == 0)
            throw new createClassCodeException("plantUML code is not generated");
           File file = new File(filecreateClassCode).getAbsoluteFile();

        
            if (!file.exists()) {
            file.createNewFile();
        }

        //PrintWriter 
        PrintWriter out = new PrintWriter(file.getAbsoluteFile());

        try {
            out.print(text);
        } catch (Exception e){
            throw new createClassCodeException("Error writing to file");
        }finally {
            out.close();
        }
        String srcPath=file.getAbsolutePath();
        String descPath=selections.getPngPath();
       // DataExtractor.generateFromFile(srcPath, descPath, "png");
       generator.generate(text, descPath, "png");
    }

    public static String endAfterLastPoint(String string, String separator){
        String[] str = string.split(separator);
        if(inArray(str, "src"))
            return str[getIndexProjectName(str, "src")];
        return str.length > 1 ? str[str.length-1] : string;
    }
    
    private static boolean inArray(String[] arr, String str){
        for (int i = 0; i < arr.length; i++){
            if(str.equals(arr[i]))
                return true;
            
        }
        return false;
    }
    
    private static int getIndexProjectName(String[] arr, String str){
        for (int i = 0; i < arr.length; i++){
            if(str.equals(arr[i]))
                return i - 1;

        }
        return 0;
        
    }

    private String getNamePackage(String path){
        String[] subString = path.split("src");
        if (subString.length > 1 && (subString[1].contains(".") || subString[1].contains("-")))
            return null;
        String namePackage = subString.length > 1 ? subString[1].replace(System.getProperty("file.separator"), ".").substring(1) : null;
        return namePackage;
    }

    private boolean packageWithFiles(File path){
        if(path.exists()){
            File[] folder = path.listFiles();
            for (int i = 0; i < folder.length; i++) {
                if (folder[i].toString().toLowerCase().endsWith(".java")) {
                    return true;
                }
            }
        }
        return false;
    }

    private void listClasses(File path) throws createClassCodeException{
        if(path.exists()) {
            File[] folder = path.listFiles();

            for (int i = 0; i < folder.length; i++) {
                if (folder[i].isDirectory()) {
                    listClasses(folder[i]);
                } else if (folder[i].toString().toLowerCase().endsWith(".java")) {
                	System.out.println("Adding classes..");
                    classes.add(getNameClass(folder[i].toString()));
                    System.out.println("Added class:"+classes);
                }
            }
        }else 
            throw new createClassCodeException("Folder is not exist");
    }

    private String getNameClass(String file){
        String[] subString = file.split(Pattern.quote(System.getProperty("file.separator")));
        String className = subString.length > 1 ? subString[subString.length - 1].replace(".java", "") : null;
        return className;
    }

    
    private void addAllconnectStringB(){

        if(selections.getHeader() != null && selections.getHeader().length() > 0)
            srcStringB.append("title " + selections.getHeader() + "\n");

            srcStringB.append(connectStringB);
            srcStringB.append(aggregation);
            srcStringB.append(composition);
            srcStringB.append(association);
            srcStringB.append(dependStringB);
        
        
    }
}
