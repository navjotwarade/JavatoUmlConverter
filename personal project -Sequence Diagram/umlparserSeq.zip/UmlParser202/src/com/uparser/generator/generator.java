package com.uparser.generator;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import net.sourceforge.plantuml.SourceStringReader;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;

import net.sourceforge.plantuml.FileFormat;
import net.sourceforge.plantuml.FileFormatOption;
import net.sourceforge.plantuml.GeneratedImage;
import net.sourceforge.plantuml.SourceFileReader;
import net.sourceforge.plantuml.SourceStringReader;


public class generator {
	 public static void generate(final String source, final String outPath, final String type) 
	    		throws FileNotFoundException, IOException {
	    	try(OutputStream out = new FileOutputStream(new File(outPath));
	    			ByteArrayOutputStream os = new ByteArrayOutputStream();) {
	    		if (source == null || outPath == null || type == null) {
	    			throw new IllegalArgumentException("generator.generate(): Wrong method arguments!");
	    		}
	    		
	    		SourceStringReader reader = new SourceStringReader(source);
	    		 if (type.equalsIgnoreCase("png")) {
	    			File file = new File(outPath);
	                if (!file.exists()) {
	                    file.createNewFile();
	                }
	                OutputStream png = new FileOutputStream(file);
	                String desc = reader.generateImage(png);	
	    		}
	        } catch (FileNotFoundException e) {
	            throw e;
	        } catch (IOException e) {
	            throw e;
	        }
	    }
}
