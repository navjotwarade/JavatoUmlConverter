package com.uparser.main;


import com.uparser.parsing.createClassCode;
import com.uparser.sequence.CreateUmlSeqenceCode;


public class Main {
	
    public static void main(String[] args) throws Exception {
       
        if (args.length < 2) {
            throw new InvalidParameterException("Enter more parameters than(" + args.length + ").");
        }
        selections.init();
        selections.setPath(args[0]);  // source path
      
        selections.setPngPath(args[1]); 
        
        //------------------------------------------------
    	 System.out.println("Class Diagram");
         // new createClassCode().writetoString();
        new CreateUmlSeqenceCode().writetoString();
        
    
        //------------------------------------------------
    
    }
}
