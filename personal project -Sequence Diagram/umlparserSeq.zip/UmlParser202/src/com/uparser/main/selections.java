package com.uparser.main;

public final class selections {
    private static String path = null;
    private static String pngpath=null;
    private static String outputFile = "classes.plantuml";
    private static String header = null;
    private static int headerSize = 30;

   

    private selections() {
    }
    
    public static void init() {
        path = null;
        
        outputFile = "classes.plantuml";
        
        header = null;
        //headerSize = 30;
  
    }

    public static String getPath() {
    	
        return path;
        
        
        
    }

    public static void setPath(String path) {
    	
    	
        selections.path = path;
        
    }
    //-----------------------------
    public static void setPngPath(String ppath) {
    	
    	
        selections.pngpath = ppath;
        
        
    }
    public static String getPngPath() {
    	
    	
        return pngpath;
        
    }
    //-----------------------------

    public static String getOutputFile() {
    	
    	
        return outputFile;
    }

    public static void setOutputFile(String outputFile) {
    	
    	
        selections.outputFile = outputFile;
        
    }

    public static String getHeader() {
    	
        return header;
        
    }

    public static void setHeader(String header) {
    	
        selections.header = header;
        
    }
    
  

   
    
}
